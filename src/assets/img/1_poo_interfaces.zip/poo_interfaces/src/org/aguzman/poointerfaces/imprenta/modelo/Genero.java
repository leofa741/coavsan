package org.aguzman.poointerfaces.imprenta.modelo;

public enum Genero {
    DRAMA,
    ACCION,
    AVENTURA,
    TERROR,
    CIENCIA_FICCION,
    PROGRAMACION
}
